# Task Manager Backend API

A RESTful backend API for a task management application.

## Tech Stack

- Node.js
- Express.js
- MongoDB
- Mongoose
- REST API
- CORS
- dotenv

## Features

- Create a task
- Get all tasks
- Get a single task
- Update a task
- Delete a task
- Task priority
- Completion status
- Due dates
- MongoDB persistence
- Input validation

## API Endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/tasks` | Get all tasks |
| GET | `/api/tasks/:id` | Get one task |
| POST | `/api/tasks` | Create task |
| PUT | `/api/tasks/:id` | Update task |
| DELETE | `/api/tasks/:id` | Delete task |

## Example POST body

```json
{
  "title": "Prepare for interview",
  "description": "Revise Node.js and MongoDB",
  "priority": "High",
  "dueDate": "2026-09-19"
}
```

## Setup

1. Install Node.js and MongoDB.
2. Open this folder in VS Code.
3. Run:

```bash
npm install
```

4. Create `.env` from `.env.example`.
5. Start the server:

```bash
npm run dev
```

6. Test:

`http://localhost:5000/`

## Interview Explanation

This project demonstrates how a Node.js and Express server exposes REST APIs and uses Mongoose to store task data in MongoDB. The API follows CRUD operations: Create, Read, Update and Delete.

## Author

Sonu Kumar
